import math
import numpy as np
import time
import optuna
from env import Env

try:
    from bayes_opt import BayesianOptimization
except:
    print(
        'Please make sure the package bayesianoptimization is installed via conda-forge or pip. \n(conda install -c conda-forge bayesian-optimization)')


def objective(x, env):
    '''


    Parameters
    ----------
    x : array
        Vector of the form [1, x1, x2, ..., x_n].
        The integers from 1 to n have to appear
        in the part [x1,..., x_n], so the number
        1 appears twice in total.
    env : environment
        Environment of the TSP-like problem.

    Returns
    -------
    obj : float
        Objective to be maximized.

    '''

    # print('x', x)
    obj_cost, rewards, pen, feas = env.check_solution(x)

    MonteCarlo = 10000  # Number of Monte Carlo samples. Higher number means less noise.
    obj = 0  # Objective averaged over Monte Carlo samples, to be maximized with surrogate optimization
    for _ in range(MonteCarlo):
        obj_cost, rewards, pen, feas = env.check_solution(x)
        # print('Time: ', obj_cost)
        # print('Rewards: ', rewards)
        # print('Penalty: ', pen)
        # print('Feasible: ', feas)
        # print('Objective: ', rewards+pen)
        obj = obj + (rewards + pen)  # Maximize the rewards + penalties (penalties are negative)
    obj /= MonteCarlo

    return obj


def check_surrogate_solution(x):
    '''


    Parameters
    ----------
    x : array
        Vector of the form [1, x1, x2, ..., x_n].
        The integers from 1 to n have to appear
        in the part [x1,..., x_n], so the number
        1 appears twice in total.

    Returns
    -------
    obj : float
        Corresponding objective.

    '''
    n_nodes = 65
    env = Env(n_nodes, seed=6537855)  # Generate instance with n_nodes nodes
    obj = objective(x, env)
    print('Solution quality (higher is better): ', obj)
    return obj


from optuna import distributions
from optuna.samplers import BaseSampler
from optuna.study import StudyDirection
from optuna.trial import TrialState


class SimulatedAnnealingSampler(BaseSampler):
    def __init__(self, temperature=100, cooldown_factor=0.9, neighbor_range_factor=0.1, seed=None):
        self._rng = np.random.RandomState(seed)
        self._independent_sampler = optuna.samplers.RandomSampler(seed=seed)
        self._temperature = temperature
        self.cooldown_factor = cooldown_factor
        self.neighbor_range_factor = neighbor_range_factor
        self._current_trial = None

    def infer_relative_search_space(self, study, trial):
        return optuna.samplers.intersection_search_space(study)

    def sample_relative(self, study, trial, search_space):
        if search_space == {}:
            # The relative search space is empty (it means this is the first trial of a study).
            return {}

        # The rest of this method is an implementation of Simulated Annealing (SA) algorithm.
        prev_trial = self._get_last_complete_trial(study)

        # Update the current state of SA if the transition is accepted.
        if self._rng.uniform(0, 1) <= self._transition_probability(study, prev_trial):
            self._current_trial = prev_trial

        # Pick a new neighbor (i.e., parameters).
        params = self._sample_neighbor_params(search_space)

        # Decrease the temperature.
        self._temperature *= self.cooldown_factor

        return params

    def _sample_neighbor_params(self, search_space):
        # Generate a sufficiently near neighbor (i.e., parameters).
        #
        # In this example, we define a sufficiently near neighbor as
        # `self.neighbor_range_factor * 100` percent region of the entire
        # search space centered on the current point.

        params = {}
        for param_name, param_distribution in search_space.items():
            if isinstance(param_distribution, distributions.UniformDistribution):
                current_value = self._current_trial.params[param_name]
                width = (
                                param_distribution.high - param_distribution.low
                        ) * self.neighbor_range_factor
                neighbor_low = max(current_value - width, param_distribution.low)
                neighbor_high = min(current_value + width, param_distribution.high)
                params[param_name] = self._rng.uniform(neighbor_low, neighbor_high)
            else:
                raise NotImplementedError(
                    "Unsupported distribution {}.".format(param_distribution)
                )

        return params

    def _transition_probability(self, study, prev_trial):
        if self._current_trial is None:
            return 1.0

        prev_value = prev_trial.value
        current_value = self._current_trial.value

        # `prev_trial` is always accepted if it has a better value than the current trial.
        if study.direction == StudyDirection.MINIMIZE and prev_value <= current_value:
            return 1.0
        elif study.direction == StudyDirection.MAXIMIZE and prev_value >= current_value:
            return 1.0

        # Calculate the probability of accepting `prev_trial` that has a worse value than
        # the current trial.
        return np.exp(-abs(current_value - prev_value) / self._temperature)

    @staticmethod
    def _get_last_complete_trial(study):
        complete_trials = study.get_trials(deepcopy=False, states=[TrialState.COMPLETE])
        return complete_trials[-1]

    def sample_independent(self, study, trial, param_name, param_distribution):
        # In this example, this method is invoked only in the first trial of a study.
        # The parameters of the trial are sampled by using `RandomSampler` as follows.
        return self._independent_sampler.sample_independent(
            study, trial, param_name, param_distribution
        )


if __name__ == '__main__':

    ##Test phase
    n_nodes = 65
    env = Env(n_nodes, seed=6537855)  # Generate instance with n_nodes nodes

    print('Generated instance (n=65). Compute the average over evaluating the same solution multiple times...')
    # sol = [1, 4, 3, 2, 5, 1]
    sol = np.arange(1, n_nodes + 1)
    np.random.shuffle(sol)
    sol = np.concatenate(([1], sol))  # Make sure solution starts at depot
    print('Solution: ', sol)
    MonteCarlo = 10000  # Number of Monte Carlo samples. Higher number means less noise.
    time1 = time.time()
    obj = 0  # Objective averaged over Monte Carlo samples, to be used for surrogate modelling
    for _ in range(MonteCarlo):
        obj_cost, rewards, pen, feas = env.check_solution(sol)
        # print('Time: ', obj_cost)
        # print('Rewards: ', rewards)
        # print('Penalty: ', pen)
        # print('Feasible: ', feas)
        # print('Objective: ', rewards+pen)
        obj = obj + (rewards + pen) / MonteCarlo
    time_elapsed1 = time.time() - time1
    print('Time elapsed: ', time_elapsed1)
    print('Average objective: ', obj)

    time2 = time.time()
    obj = 0  # Objective averaged over Monte Carlo samples, to be used for surrogate modelling
    for _ in range(MonteCarlo):
        obj_cost, rewards, pen, feas = env.check_solution(sol)
        # print('Time: ', obj_cost)
        # print('Rewards: ', rewards)
        # print('Penalty: ', pen)
        # print('Feasible: ', feas)
        # print('Objective: ', rewards+pen)
        obj = obj + (rewards + pen) / MonteCarlo
    time_elapsed2 = time.time() - time2
    print('Time elapsed: ', time_elapsed2)
    print('Average objective: ', obj)

    time3 = time.time()
    obj = 0  # Objective averaged over Monte Carlo samples, to be used for surrogate modelling
    for _ in range(MonteCarlo):
        obj_cost, rewards, pen, feas = env.check_solution(sol)
        # print('Time: ', obj_cost)
        # print('Rewards: ', rewards)
        # print('Penalty: ', pen)
        # print('Feasible: ', feas)
        # print('Objective: ', rewards+pen)
        obj = obj + (rewards + pen) / MonteCarlo
    time_elapsed3 = time.time() - time3
    print('Time elapsed: ', time_elapsed3)
    print('Average objective: ', obj)

    print('Evaluating the objective function takes about ', (time_elapsed1 + time_elapsed2 + time_elapsed3) / 3,
          ' seconds on this machine.')


    def x_to_route(x):
        # After rounding x, transform it to a route.
        nodes = np.arange(1, n_nodes + 1).tolist()
        xnew = []
        for xi in x:
            i = int(xi)
            xnew.append(nodes[i])
            nodes.remove(nodes[i])
        xnew.insert(0, 1)  # Start from starting depot
        print(xnew)

        return xnew

    def x_to_route_2(x):
        # After rounding x, transform it to a route.

        xnew = sorted(range(len(x)), key=lambda k: x[k])
        xnew.insert(0, 1)  # Start from starting depot
        # print(xnew)

        return xnew


    def objOptuna(trial):

        # names = locals()
        # for i in range(n_nodes):
        #     names['v' + str(i) ] = trial.suggest_uniform('v' + str(i), 0.0, max(1e-4, n_nodes - i - 1e-4))

        v0 = trial.suggest_float('v0', 0.0, 1.0, step=0.01)
        v1 = trial.suggest_float('v1', 0.0, 1.0, step=0.01)
        v2 = trial.suggest_float('v2', 0.0, 1.0, step=0.01)
        v3 = trial.suggest_float('v3', 0.0, 1.0, step=0.01)
        v4 = trial.suggest_float('v4', 0.0, 1.0, step=0.01)
        v5 = trial.suggest_float('v5', 0.0, 1.0, step=0.01)
        v6 = trial.suggest_float('v6', 0.0, 1.0, step=0.01)
        v7 = trial.suggest_float('v7', 0.0, 1.0, step=0.01)
        v8 = trial.suggest_float('v8', 0.0, 1.0, step=0.01)
        v9 = trial.suggest_float('v9', 0.0, 1.0, step=0.01)
        v10 = trial.suggest_float('v10', 0.0, 1.0, step=0.01)
        v11 = trial.suggest_float('v11', 0.0, 1.0, step=0.01)
        v12 = trial.suggest_float('v12', 0.0, 1.0, step=0.01)
        v13 = trial.suggest_float('v13', 0.0, 1.0, step=0.01)
        v14 = trial.suggest_float('v14', 0.0, 1.0, step=0.01)
        v15 = trial.suggest_float('v15', 0.0, 1.0, step=0.01)
        v16 = trial.suggest_float('v16', 0.0, 1.0, step=0.01)
        v17 = trial.suggest_float('v17', 0.0, 1.0, step=0.01)
        v18 = trial.suggest_float('v18', 0.0, 1.0, step=0.01)
        v19 = trial.suggest_float('v19', 0.0, 1.0, step=0.01)
        v20 = trial.suggest_float('v20', 0.0, 1.0, step=0.01)
        v21 = trial.suggest_float('v21', 0.0, 1.0, step=0.01)
        v22 = trial.suggest_float('v22', 0.0, 1.0, step=0.01)
        v23 = trial.suggest_float('v23', 0.0, 1.0, step=0.01)
        v24 = trial.suggest_float('v24', 0.0, 1.0, step=0.01)
        v25 = trial.suggest_float('v25', 0.0, 1.0, step=0.01)
        v26 = trial.suggest_float('v26', 0.0, 1.0, step=0.01)
        v27 = trial.suggest_float('v27', 0.0, 1.0, step=0.01)
        v28 = trial.suggest_float('v28', 0.0, 1.0, step=0.01)
        v29 = trial.suggest_float('v29', 0.0, 1.0, step=0.01)
        v30 = trial.suggest_float('v30', 0.0, 1.0, step=0.01)
        v31 = trial.suggest_float('v31', 0.0, 1.0, step=0.01)
        v32 = trial.suggest_float('v32', 0.0, 1.0, step=0.01)
        v33 = trial.suggest_float('v33', 0.0, 1.0, step=0.01)
        v34 = trial.suggest_float('v34', 0.0, 1.0, step=0.01)
        v35 = trial.suggest_float('v35', 0.0, 1.0, step=0.01)
        v36 = trial.suggest_float('v36', 0.0, 1.0, step=0.01)
        v37 = trial.suggest_float('v37', 0.0, 1.0, step=0.01)
        v38 = trial.suggest_float('v38', 0.0, 1.0, step=0.01)
        v39 = trial.suggest_float('v39', 0.0, 1.0, step=0.01)
        v40 = trial.suggest_float('v40', 0.0, 1.0, step=0.01)
        v41 = trial.suggest_float('v41', 0.0, 1.0, step=0.01)
        v42 = trial.suggest_float('v42', 0.0, 1.0, step=0.01)
        v43 = trial.suggest_float('v43', 0.0, 1.0, step=0.01)
        v44 = trial.suggest_float('v44', 0.0, 1.0, step=0.01)
        v45 = trial.suggest_float('v45', 0.0, 1.0, step=0.01)
        v46 = trial.suggest_float('v46', 0.0, 1.0, step=0.01)
        v47 = trial.suggest_float('v47', 0.0, 1.0, step=0.01)
        v48 = trial.suggest_float('v48', 0.0, 1.0, step=0.01)
        v49 = trial.suggest_float('v49', 0.0, 1.0, step=0.01)
        v50 = trial.suggest_float('v50', 0.0, 1.0, step=0.01)
        v51 = trial.suggest_float('v51', 0.0, 1.0, step=0.01)
        v52 = trial.suggest_float('v52', 0.0, 1.0, step=0.01)
        v53 = trial.suggest_float('v53', 0.0, 1.0, step=0.01)
        v54 = trial.suggest_float('v54', 0.0, 1.0, step=0.01)
        v55 = trial.suggest_float('v55', 0.0, 1.0, step=0.01)
        v56 = trial.suggest_float('v56', 0.0, 1.0, step=0.01)
        v57 = trial.suggest_float('v57', 0.0, 1.0, step=0.01)
        v58 = trial.suggest_float('v58', 0.0, 1.0, step=0.01)
        v59 = trial.suggest_float('v59', 0.0, 1.0, step=0.01)
        v60 = trial.suggest_float('v60', 0.0, 1.0, step=0.01)
        v61 = trial.suggest_float('v61', 0.0, 1.0, step=0.01)
        v62 = trial.suggest_float('v62', 0.0, 1.0, step=0.01)
        v63 = trial.suggest_float('v63', 0.0, 1.0, step=0.01)
        v64 = trial.suggest_float('v64', 0.0, 1.0, step=0.01)

        xvars = [v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17,
                 v18, v19, v20, v21, v22, v23, v24, v25, v26, v27, v28, v29, v30, v31, v32,
                 v33, v34, v35, v36, v37, v38, v39, v40, v41, v42, v43, v44, v45, v46, v47,
                 v48, v49, v50, v51, v52, v53, v54, v55, v56, v57, v58, v59, v60, v61, v62,
                 v63, v64]

        # xrounded = np.floor(np.asarray(xvars))
        # xnew = x_to_route(xrounded)

        xnew = x_to_route_2(xvars)

        r = objective(xnew, env)

        eps = 1e-3
        rnoise = r + np.random.standard_normal() * eps
        return rnoise

    # sampler = SimulatedAnnealingSampler() #
    # sampler = optuna.samplers.CmaEsSampler()
    sampler = optuna.samplers.TPESampler(seed=2021)
    study = optuna.create_study(direction='maximize',sampler=sampler)
    study.optimize(objOptuna, n_trials=10000)

    solX = []
    for i in range(n_nodes):
        solX.append(study.best_params[f'v{i}'])
    route_solX = x_to_route_2(solX)


    def objBO(**x):
        vars = [f'v{i}' for i in range(n_nodes)]
        xvars = [x[v] for v in vars]

        # Bayesianoptimisation does not naturally support integer variables.
        # As such we round them.
        xrounded = np.floor(np.asarray(xvars))
        xnew = x_to_route(xrounded)

        r = objective(xnew, env)

        # Bayesianoptimization maximizes by default.
        # Include some random noise to avoid issues if all samples are the same.
        eps = 1e-6
        rnoise = r + np.random.standard_normal() * eps
        return rnoise


    # varnames = {f'v{i}' for i in range(n_nodes)}
    # pbounds = {f'v{i}': (0.0, max(1e-4, n_nodes - i - 1e-4))
    #            # keep upper bound above 0 to avoid numerical errors, but subtract a small number so the np.floor function does the right thing
    #            for i in range(n_nodes)}
    #
    # optimizer = BayesianOptimization(
    #     f=objBO,
    #     pbounds=pbounds,
    #     verbose=2
    # )
    #
    # random_init_evals = 10
    # max_evals = 100
    # optimizer.maximize(
    #     init_points=random_init_evals,
    #     n_iter=max_evals - random_init_evals)
    #
    # print('Finished optimizing with surrogate model.')
    #
    # solX = []
    # for i in range(n_nodes):
    #     solX.append(optimizer.max['params'][f'v{i}'])

    # solY = optimizer.max['target']
    # print('Solution: ', solX)
    # print('Objective: ', solY)
    # route_solX = np.floor(np.asarray(solX))
    # print('Rounded solution: ', route_solX)
    # route_solX = x_to_route(route_solX)
    # print('Route: ', route_solX)

    print('Do one run using this solution.')
    obj_cost, rewards, pen, feas = env.check_solution(route_solX)
    print('Time: ', obj_cost)
    print('Rewards: ', rewards)
    print('Penalty: ', pen)
    print('Feasible: ', feas)
    print('Objective: ', rewards + pen)

    print('Average objective using the found solution:', objective(route_solX, env))

    write_output = True
    file = str(rewards + pen) + '.out'
    if write_output:
        fileObject = open(file, 'w')
        for x in route_solX:
            fileObject.write(str(x))
            fileObject.write('\n')
        fileObject.close()
